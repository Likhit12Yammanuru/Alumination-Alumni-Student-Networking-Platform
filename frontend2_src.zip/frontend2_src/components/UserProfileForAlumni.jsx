// UserProfileForAlumni.jsx

import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import "./UserProfile.css";

const UserProfileForAlumni = () => {
  const { id } = useParams();
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState("");

  const alumniName = localStorage.getItem("alumniName") || "Anonymous";

  useEffect(() => {
    axios.get(`http://localhost:5000/api/users/${id}`)
      .then((res) => setUser(res.data))
      .catch((err) => console.error("Error fetching user:", err));
  }, [id]);

  const sendMessage = async () => {
    try {
      await axios.post("http://localhost:5000/api/alumni/messages", {
        from: alumniName,
        to: id,
        message,
      });
      setStatus("Message sent!");
      setMessage("");
    } catch (err) {
      setStatus("Failed to send message.");
    }
  };

  if (!user) return <div>Loading user profile...</div>;

  return (
    <div className="user-profile">
      <img src={user.image} alt={user.name} onError={(e) => { e.target.src = "https://via.placeholder.com/100"; }} />
      <h2>{user.name}</h2>
      <p><strong>Registration Number:</strong> {user.regNo}</p>
      <p><strong>Semester:</strong> {user.semester}</p>

      <textarea
        placeholder="Write your message..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      <button onClick={sendMessage}>Send Message</button>
      {status && <p>{status}</p>}
    </div>
  );
};

export default UserProfileForAlumni;
