const Help = () => {
  return <div className="page">❓ Help and support for alumni here.</div>;
};

export default Help;
