import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./Inbox.css";

const Inbox = () => {
  const [messages, setMessages] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:5000/api/alumni-inbox") // Fetch messages for Alumni Inbox
      .then(res => setMessages(res.data))
      .catch(err => console.error("Failed to fetch inbox:", err));
  }, []);

  return (
    <div className="inbox-container">
      <h2>Your Messages</h2>
      {messages.length === 0 ? (
        <p>No conversations yet</p>
      ) : (
        messages.map((msg, index) => (
          <div
            key={index}
            className="inbox-item"
            onClick={() => navigate(`/dm/${msg.from}`)} // Navigate to DM page for specific user
          >
            <img src={msg.image} alt={msg.name} className="avatar" />
            <div>
              <strong>{msg.from}</strong>
              <p>{msg.message}</p>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default Inbox;
