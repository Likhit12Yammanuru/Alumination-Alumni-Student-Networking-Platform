const GetAnnouncement = () => {
  return <div className="page">📢 Announcements sent by users will appear here.</div>;
};

export default GetAnnouncement;
